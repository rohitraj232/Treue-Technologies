import React from 'react'
import './style.css'

function Home() {
  return (
    <div className="main">
        <div className="hero">
          <h2>Welcome To Home Page!</h2>
          <p>You have successfully logged in.</p>
        </div>
    </div>
  )
}

export default Home
